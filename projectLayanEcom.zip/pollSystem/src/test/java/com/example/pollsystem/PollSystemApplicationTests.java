package com.example.pollsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PollSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
