package com.example.pollsystem.service;

import com.example.pollsystem.model.User;
import com.example.pollsystem.repository.AnswerRepository;
import com.example.pollsystem.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final AnswerRepository answerRepository;

    public UserService(UserRepository userRepository, AnswerRepository answerRepository) {
        this.userRepository = userRepository;
        this.answerRepository = answerRepository;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Transactional
    public Optional<User> updateUser(Long id, User updatedUser) {
        return userRepository.findById(id).map(user -> {
            user.setFirstName(updatedUser.getFirstName());
            user.setLastName(updatedUser.getLastName());
            user.setEmail(updatedUser.getEmail());
            user.setAge(updatedUser.getAge());
            user.setAddress(updatedUser.getAddress());
            user.setJoiningDate(updatedUser.getJoiningDate());
            return userRepository.save(user);
        });
    }

    @Transactional
    public void deleteUser(Long id) {
        answerRepository.deleteByUserId(id);
        userRepository.deleteById(id);
    }
}
