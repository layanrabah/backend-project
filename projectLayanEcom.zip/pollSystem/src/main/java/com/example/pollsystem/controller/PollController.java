package com.example.pollsystem.controller;

import com.example.pollsystem.model.Poll;
import com.example.pollsystem.service.PollService;
import com.example.pollsystem.service.AnswerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/polls")
public class PollController {

    private final PollService pollService;
    private final AnswerService answerService;

    public PollController(PollService pollService, AnswerService answerService) {
        this.pollService = pollService;
        this.answerService = answerService;
    }

    @PostMapping
    public Poll createPoll(@RequestBody Poll poll) {
        return pollService.createPoll(poll);
    }

    @GetMapping
    public List<Poll> getAllPolls() {
        return pollService.getAllPolls();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Poll> getPollById(@PathVariable Long id) {
        return pollService.getPollById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Poll> updatePoll(@PathVariable Long id, @RequestBody Poll poll) {
        return pollService.updatePoll(id, poll)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePoll(@PathVariable Long id) {
        pollService.deletePoll(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{pollId}/countOptions")
    public ResponseEntity<Map<String, Long>> getCountByPollId(@PathVariable Long pollId) {
        return ResponseEntity.ok(answerService.getCountByPollId(pollId));
    }

    @GetMapping("/{pollId}/total")
    public ResponseEntity<Long> getTotalAnswersByPollId(@PathVariable Long pollId) {
        return ResponseEntity.ok(answerService.getTotalAnswersByPollId(pollId));
    }

    @GetMapping("/withAnswerCounts")
    public ResponseEntity<List<Map<String, Object>>> getAllQuestionsWithAnswerCounts() {
        return ResponseEntity.ok(pollService.getAllQuestionsWithAnswerCounts());
    }
}
