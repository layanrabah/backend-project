package com.example.pollsystem.controller;

import com.example.pollsystem.dto.AnswerDTO;
import com.example.pollsystem.model.Answer;
import com.example.pollsystem.service.AnswerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/answers")
public class AnswerController {

    private final AnswerService answerService;

    public AnswerController(AnswerService answerService) {
        this.answerService = answerService;
    }

    @PostMapping
    public ResponseEntity<AnswerDTO> saveAnswer(@RequestBody Answer answer) {
        Answer savedAnswer = answerService.saveAnswer(answer);
        AnswerDTO answerDTO = new AnswerDTO(
                savedAnswer.getId(),
                savedAnswer.getUser().getId(),
                savedAnswer.getPoll().getId(),
                savedAnswer.getSelectedOption()
        );
        return ResponseEntity.ok(answerDTO);
    }

    @GetMapping("/user/{userId}/answers")
    public ResponseEntity<List<AnswerDTO>> getAnswersByUserId(@PathVariable Long userId) {
        List<AnswerDTO> answers = answerService.getAnswersByUserId(userId);
        return ResponseEntity.ok(answers);
    }

    @GetMapping("/user/{userId}/total")
    public ResponseEntity<Long> getTotalQuestionsAnsweredByUser(@PathVariable Long userId) {
        Long total = answerService.getTotalQuestionsAnsweredByUser(userId);
        return ResponseEntity.ok(total);
    }

    @GetMapping("/poll/{pollId}/countOptions")
    public ResponseEntity<Map<String, Long>> getCountByPollId(@PathVariable Long pollId) {
        Map<String, Long> counts = answerService.getCountByPollId(pollId);
        return ResponseEntity.ok(counts);
    }

    @GetMapping("/poll/{pollId}/total")
    public ResponseEntity<Long> getTotalAnswersByPollId(@PathVariable Long pollId) {
        Long total = answerService.getTotalAnswersByPollId(pollId);
        return ResponseEntity.ok(total);
    }
}
