package com.example.pollsystem.repository;

import com.example.pollsystem.model.Answer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface AnswerRepository extends JpaRepository<Answer, Long> {

    @Modifying
    @Transactional
    void deleteByUserId(Long userId);

    @Query("SELECT a.selectedOption, COUNT(a) FROM Answer a WHERE a.poll.id = :pollId GROUP BY a.selectedOption")
    List<Object[]> countAnswersByPollId(Long pollId);

    @Query("SELECT COUNT(a) FROM Answer a WHERE a.poll.id = :pollId")
    Long countByPollId(Long pollId);

    List<Answer> findByUserId(Long userId);

    @Query("SELECT COUNT(a) FROM Answer a WHERE a.user.id = :userId")
    Long countByUserId(Long userId);
}
